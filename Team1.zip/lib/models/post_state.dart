enum PostState {
  liked,
  disliked,
  neither,
}
